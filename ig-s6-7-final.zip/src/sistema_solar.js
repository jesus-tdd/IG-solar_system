import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";

let scene, renderer;
let camera, camcontrols;
let objetos = [];

function init() {
    info = document.createElement("div");
    info.id = "info";
    info.innerHTML = "sistema solar";
    document.body.appendChild(info);

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(
        75,
        window.innerWidth / window.innerHeight,
        0.1,
        1000
    );
    camera.position.set(0, 0, 10);

    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    camcontrols = new OrbitControls(camera, renderer.domElement);
}

function animationLoop() {
    requestAnimationFrame(animationLoop);
  
    renderer.render(scene, camera);
  }